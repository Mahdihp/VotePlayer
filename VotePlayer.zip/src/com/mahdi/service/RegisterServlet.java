package com.mahdi.service;

import com.mahdi.service.dao.ItemDao;
import com.mahdi.service.dao.QuestionDao;
import com.mahdi.service.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "RegisterServlet", urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {

    QuestionDao questionDao = null;
    ItemDao itemDao = null;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            questionDao = new QuestionDao();
            itemDao = new ItemDao();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String question = null;
        try {
            question = questionDao.getLastQuestion().getQuestion();
//            System.out.println("Log-----" + question);
            request.setAttribute("question",question);
            request.setAttribute("items",itemDao.getLastItem(1));
            request.getRequestDispatcher("home.jsp").forward(request,response);
//            response.sendRedirect("home.jsp?question=" + question + "&items=" + itemDao.getLastItem());
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
